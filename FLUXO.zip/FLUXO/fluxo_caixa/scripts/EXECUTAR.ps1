# Script PowerShell para executar a aplicacao Fluxo de Caixa
Set-Location -Path "$PSScriptRoot\.."
python app\main.py
