"""Configurações do projeto"""
from .settings import Settings
from .constants import *

__all__ = ['Settings']

