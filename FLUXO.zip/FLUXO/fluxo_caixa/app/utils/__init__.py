"""Utilitários da aplicação"""

