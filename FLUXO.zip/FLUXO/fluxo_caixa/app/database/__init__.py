"""
Database - Módulo de Persistência
Contém camada de acesso a dados e configurações de banco
"""

from .database import Database

__all__ = ['Database']

